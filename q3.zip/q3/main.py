import Search
from City import City
import random
import statistics


# TSP:
# Salesman has to make a full tour, starting at city A and returning to city A.


def cities_generator(num):
    cities = []
    for i in range(0, num):
        x = random.uniform(0.0, 1.0)
        y = random.uniform(0.0, 1.0)
        city = "c" + str(i)
        cities.append(City(city, x, y))
    return cities


def print_brute_force(num):
    print("BRUTE FORCE")
    paths = []
    costs = []
    for i in range(0, 100):
        cities = cities_generator(num)
        path, cost = Search.brute_force(cities)
        costs.append(cost)
        paths.append(path)

    # for i in range(0, 100):
    #     print("PATH: ", paths[i])
    #     print("COST: ", costs[i])
    #     print()

    print("min-cost: ", min(costs))
    print("max-cost: ", max(costs))
    print("mean: ", statistics.mean(costs))
    print("standard deviation: ", statistics.stdev(costs))


def print_random_search(num, instances, compare_to_opt, update_me=False):
    print("RANDOM SEARCH: ")
    optimal_cost = []
    rand_cost = []
    rand_is_opt = 0
    for i in range(0, instances):
        cities = cities_generator(num)
        (path, cost) = Search.random_search(cities, True)
        rand_cost.append(cost)
        if compare_to_opt:
            (path, cost) = Search.brute_force(cities)
            optimal_cost.append(cost)
            if rand_cost[i] == optimal_cost[i]:
                rand_is_opt += 1
        if update_me and (i % 25 == 0):
            print(str(i) + " Iterations done!")

    print("min-cost: ", min(rand_cost))
    print("max-cost: ", max(rand_cost))
    print("mean: ", statistics.mean(rand_cost))
    print("standard deviation: ", statistics.stdev(rand_cost))
    if compare_to_opt:
        print("Optimal solutions: ", rand_is_opt)


def print_hill_climbing(num, instances, compare_to_opt, update_me=False):
    print("HILL CLIMBING: ")
    optimal_cost = []
    hc_cost = []
    hc_is_opt = 0
    for i in range(0, instances):
        cities = cities_generator(num)
        path, cost = Search.hill_climbing(cities)
        hc_cost.append(cost)
        if compare_to_opt:
            path, cost = Search.brute_force(cities)
            optimal_cost.append(cost)
            if optimal_cost[i] == hc_cost[i]:
                hc_is_opt += 1
        if update_me and (i % 10 == 0):
            print(str(i) + "% done!")

    print("min-cost: ", min(hc_cost))
    print("max-cost: ", max(hc_cost))
    print("mean: ", statistics.mean(hc_cost))
    print("standard deviation: ", statistics.stdev(hc_cost))
    if compare_to_opt:
        print("Optimal solutions: ", hc_is_opt)


print("\n a)")
print_brute_force(7)
print("\n b)")
print_random_search(7, 100, True)
print("\n c)")
print_hill_climbing(7, 100, True)
print("\n 100 instances of 100 Cities:")
print("\n d)")
print_random_search(100, 100, False)
print()
print_hill_climbing(100, 100, False, True)

# print(Search.two_change(["A", "B", "C", "D", "E", "F", "G", "H", "A"], 3, 6))

# cities = []
# cities.append(City("a", 1, 0))
# cities.append(City("b", 1, 2))
# cities.append(City("c", 0, 0))
# cities.append(City("d", 2, 2))

# print(Search.brute_force(cities))
