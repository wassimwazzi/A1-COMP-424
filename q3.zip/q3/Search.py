import random

from itertools import permutations


def path_distance(cities_obj):
    total_distance = 0
    length = len(cities_obj)
    for i in range(0, length - 1):
        total_distance += cities_obj[i] - cities_obj[i + 1]
    total_distance += cities_obj[length - 1] - cities_obj[0]  # return to start state
    return total_distance


def brute_force(cities_obj):
    all_paths = list(permutations(cities_obj))
    all_distances = []
    for i in all_paths:
        all_distances.append(path_distance(i))
    min_distance = min(all_distances)
    optimal_path_obj = all_paths[all_distances.index(min_distance)]

    optimal_path = []
    for i in optimal_path_obj:
        optimal_path.append(i.city)
    return optimal_path, min_distance


# select a random tour
def random_search(cities_obj, return_cost):
    new_cities_obj = cities_obj[:]
    random.shuffle(new_cities_obj)
    if return_cost:
        return new_cities_obj, path_distance(new_cities_obj)
    else:
        return new_cities_obj


def two_change(path, i, k):
    new_path = path[:]
    tmp = path[i:k + 1]
    list.reverse(tmp)
    new_path[i:k + 1] = tmp
    return new_path


def hill_climbing(path):
    cur_path = random_search(path, False)
    cur_best_cost = path_distance(cur_path)
    best_path = cur_path[:]
    n = len(cur_path)
    improvement = True
    while improvement:
        improvement = False
        for i in range(0, n):
            for j in range(i + 1, n + 1):
                new_path = two_change(best_path, i, j)
                new_cost = path_distance(new_path)
                if new_cost < cur_best_cost:
                    cur_best_cost = new_cost
                    best_path = new_path
                    improvement = True
    return best_path, cur_best_cost

