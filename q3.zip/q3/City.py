import math


class City:

    def __init__(self, city, x, y):
        self.city = city
        self.x = x
        self.y = y

    def __sub__(self, other):
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
