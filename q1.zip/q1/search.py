import helpers
import copy


def bfs(cur_state_obj, goal_state_obj):
    print("BFS")
    visited_states = [cur_state_obj.state]
    queue = [cur_state_obj]
    while queue:
        n = queue.pop(0)
        if n.state == goal_state_obj.state:
            break
        next_states = helpers.get_next_states(n)
        sorted_next_states = sorted(next_states, key=lambda state_obj: state_obj.cost, reverse=True)

        for i in sorted_next_states:
            if i not in visited_states:
                i.total_cost = n.total_cost + 1
                visited_states.append(i.state)
                queue.append(i)
    print("Total cost: ", n.total_cost)
    helpers.print_path(n)


# In this case, uniform cost is the same as BFS, so we just copy BFS algorithm
def unit_cost_uniform_search(cur_state_obj, goal_state_obj):
    print("Uniform-cost Search")
    visited_states = [cur_state_obj.state]
    queue = [cur_state_obj]
    while queue:
        n = queue.pop(0)
        if n.state == goal_state_obj.state:
            break
        next_states = helpers.get_next_states(n)
        sorted_next_states = sorted(next_states, key=lambda state_obj: state_obj.cost, reverse=True)

        for i in sorted_next_states:
            if i not in visited_states:
                i.total_cost = n.total_cost + 1
                visited_states.append(i.state)
                queue.append(i)
    print("Total cost: ", n.total_cost)
    helpers.print_path(n)


def dfs(cur_state_obj, goal_state_obj):
    print("DFS")
    visited_states = [cur_state_obj.state]
    stack = [cur_state_obj]
    while stack:
        n = stack.pop()
        if n.state == goal_state_obj.state:
            break
        next_states = helpers.get_next_states(n)
        sorted_next_states = sorted(next_states, key=lambda state_obj: state_obj.cost, reverse=True)

        for i in sorted_next_states:
            if i.state not in visited_states:
                i.total_cost = n.total_cost + 1
                visited_states.append(i.state)
                stack.append(i)

    print("Total cost: ", n.total_cost)
    helpers.print_path(n)


def ids(cur_state_obj, goal_state_obj, max_depth):
    print("IDS")
    initial_state_obj = copy.copy(cur_state_obj)
    for cur_depth in range(0, max_depth):
        cur_state_obj = initial_state_obj
        visited_states = [cur_state_obj.state]
        stack = [cur_state_obj]
        while stack:
            n = stack.pop()
            if n.state == goal_state_obj.state:
                break
            next_states = helpers.get_next_states(n)
            sorted_next_states = sorted(next_states, key=lambda state_obj: state_obj.cost, reverse=True)

            for i in sorted_next_states:
                if i.state not in visited_states:
                    i.total_cost = n.total_cost + 1
                    if i.total_cost <= cur_depth:
                        visited_states.append(i.state)
                        stack.append(i)

        if n.state == goal_state_obj.state:
            break

    print("Total cost: ", n.total_cost)
    helpers.print_path(n)
