from State import State


def can_move_up(state):
    pos = state.index(0)
    if pos > 2:
        return True
    else:
        return False


def can_move_down(state):
    pos = state.index(0)
    if pos < 3:
        return True
    else:
        return False


def can_move_left(state):
    pos = state.index(0)
    if pos == 3 or pos == 0:
        return False
    else:
        return True


def can_move_right(state):
    pos = state.index(0)
    if pos == 2 or pos == 5:
        return False
    else:
        return True


def move_up(state):
    pos = state.index(0)
    tmp = state[pos - 3]
    state[pos - 3] = 0
    state[pos] = tmp
    return state


def move_down(state):
    pos = state.index(0)
    tmp = state[pos + 3]
    state[pos + 3] = 0
    state[pos] = tmp
    return state


def move_left(state):
    pos = state.index(0)
    tmp = state[pos - 1]
    state[pos - 1] = 0
    state[pos] = tmp
    return state


def move_right(state):
    pos = state.index(0)
    tmp = state[pos + 1]
    state[pos + 1] = 0
    state[pos] = tmp
    return state


def get_next_states(state_obj):
    next_states = []
    s1 = state_obj.state[:]
    s2 = state_obj.state[:]
    s3 = state_obj.state[:]
    s4 = state_obj.state[:]
    if can_move_up(s1):
        pos = s1.index(0)
        p = s1[pos - 3]
        s = State(move_up(s1), p, state_obj)
        next_states.append(s)
    if can_move_down(s2):
        pos = s2.index(0)
        p = s2[pos + 3]
        s = State(move_down(s2), p, state_obj)
        next_states.append(s)
    if can_move_right(s3):
        pos = s3.index(0)
        p = s3[pos + 1]
        s = State(move_right(s3), p, state_obj)
        next_states.append(s)
    if can_move_left(s4):
        pos = s4.index(0)
        p = s4[pos - 1]
        s = State(move_left(s4), p, state_obj)
        next_states.append(s)
    return next_states


def display_state(state_obj):
    print(state_obj.state[:3])
    print(state_obj.state[3:])
    print()


def is_in_visited(state, visited_states):
    for p_s in visited_states:
        if (state == p_s.state):
            return True
    return False


def print_path(state_obj, steps=0):
    if state_obj:
        if state_obj.prev:
            steps += 1
        print_path(state_obj.prev, steps)
        display_state(state_obj)
    else:
        print("Steps: ", steps)


# debug:
def print_list(list):
    for i in list:
        display_state(i)


def disp(state):
    print(state[:3])
    print(state[3:])
    print()


def print_visited(list):
    for i in list:
        disp(i)
