import search
from State import State

#6-puzzle solver:

cur_state = [1, 4, 2, 5, 3, 0]
goal_state = [0, 1, 2, 5, 4, 3]

cur_state_obj = State(cur_state)
goal_state_obj = State(goal_state)

search.bfs(cur_state_obj, goal_state_obj)
search.unit_cost_uniform_search(cur_state_obj, goal_state_obj)
search.dfs(cur_state_obj, goal_state_obj)
search.ids(cur_state_obj, goal_state_obj, 200)